import 'regenerator-runtime'; 
import '../styles/main.css';
import main from '../component/main';
document.addEventListener('DOMContentLoaded', main );