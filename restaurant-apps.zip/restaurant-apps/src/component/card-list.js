class CardList extends HTMLElement{
    constructor(){
        super();
        this.shadowDOM  = this.attachShadow({mode: "open"});
    }

    connectedCallback(){
      this.render();
    }
    
    render(){
        this.shadowDOM.innerHTMl =
        `
        <style>
        .card-list{
          position: absolute;
          padding: 90px 3px;
          width: fit-content;
          box-shadow: 0 10px 10px 0 rgba(0,0,0,0.2);
          transition: 0.3s;
          }
          
          .containerCard{
          border: 1px solid #ddd;
          border-radius: 4px;
          padding: 1px 1px;
          position: relative;
          bottom: 78px;
        
        
          }
        
          img{
          width: fit-content;
        
          }
          
        
          h2, h1{
          text-align: center;
          }
        
        
        
          
        </style>

      `
    }
}

customElements.define('card-list', CardList);

