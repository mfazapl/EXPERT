import restaurantData from '../DATA.json';
import './card-list';


const main = () => {
    const cardDisplay =document.querySelector('card-list');

    restaurantData.restaurants.forEach((restaurant) =>{
        const card = document.createElement('div');
        card.classList.add('containerCard');
        const image = document.createElement('img');
        image.src = restaurant.pictureId;

        card.appendChild(image);

        const content = document.createElement('div');
        content.classList.add('container');
        const name = document.createElement('h1');
        name.textContent = restaurant.name;
        const description = document.createElement('h1');
        description.textContent = restaurant.description;
        const city = document.createElement('h2');
        city.textContent = restaurant.city;
        const rating = document.createElement('h1');
        rating.textContent = restaurant.rating;

        content.appendChild(name);
        content.appendChild(description);
        content.appendChild(city);
        content.appendChild(rating);

        card.appendChild(content);

        cardDisplay.appendChild(card);


    })

    
};

export default main;